import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/adddrouteindatabaselinkgeneratedbymuhii")

public class Addroute extends HttpServlet {
   protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		        String  Stateto    = request.getParameter("ADDMINrouteforstateto");
		        String  Statefrom  = request.getParameter("ADDMINrouteforstatefrom");
                String  Travelid   = request.getParameter("ftravelid");
                String  Busid      = request.getParameter("fbusid");
                String  Departure  = request.getParameter("fdeparture");
                String  Arrival    = request.getParameter("fArrival");
                String  fare       = request.getParameter("fare");
                
                System.out.print(Stateto);
                System.out.print(Statefrom);
                System.out.print(Statefrom);
                System.out.print(Busid);
                System.out.print(Departure); 
                
                
                try
                {
               	
			Class.forName("oracle.jdbc.driver.OracleDriver");
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		String username="system";
			String password="juhikarn";
			Connection con=DriverManager.getConnection(url,username,password); 
			System.out.println("Created DB Connection....");
			
			PreparedStatement stmt=con.prepareStatement("insert into VIEWROUTE values(?,?,?,?,?,?,?)");  
			stmt.setString(1,Stateto);
			stmt.setString(2,Statefrom);  
			stmt.setString(3,Travelid);  
			stmt.setString(4,Busid);  
			stmt.setString(5,Departure); 
			stmt.setString(6,Arrival);  
			stmt.setString(7,fare); 
			
			
							    
			stmt.executeUpdate();
			
		         out.print("success fully added");
		         
		            con.close();
		        } catch (ClassNotFoundException e) {
		            
		            e.printStackTrace();
		        } catch (SQLException e) {
		            
	            e.printStackTrace();
		        }
		
		

	}

}