import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/circulationcontrol")
public class Register extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		
		String User= request.getParameter("user");			
		String Email= request.getParameter("Email");	
		String Password= request.getParameter("password");
                String Term= request.getParameter("term");

                
                
		try{  
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url="jdbc:oracle:thin:@localhost:1521:xe";
			String username="system";
			String password="juhikarn";
			Connection con=DriverManager.getConnection(url,username,password); 
			
			System.out.println("Created DB Connection....");
			
		    
			PreparedStatement stmt=con.prepareStatement("insert into userRegister values(?,?,?,?)");  
			
			stmt.setString(1,User);
			stmt.setString(2,Email);  
			stmt.setString(3,Password);  
			stmt.setString(4,Term);  

			stmt.executeUpdate();
			
		         out.print("success fully");
                         
                         
                           RequestDispatcher rd=request.getRequestDispatcher("user.html");
				rd.include(request, response);
		         
		            con.close();
		        } catch (ClassNotFoundException e) {
		            
		            e.printStackTrace();
		        } catch (SQLException e) {
		            
		            e.printStackTrace();
		        } 
		
    }  
}
