import org.json.simple.JSONValue;
import java.sql.*;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;


import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/Circulationkkkwwwwwwwwwwertyui")
public class Viewroute extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			response.setContentType("application/json");
			response.setCharacterEncoding("UTF-8");
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","juhikarn");
			PreparedStatement select=con.prepareStatement("select * from VIEWROUTE");
			
			ResultSet rs=select.executeQuery();
			JSONObject jsonObject = new JSONObject();
			
		    JSONArray array1 = new JSONArray();
		    JSONArray array2 = new JSONArray();
		    JSONArray array3 = new JSONArray();
		    JSONArray array4 = new JSONArray();
		    JSONArray array5 = new JSONArray();
		    JSONArray array6 = new JSONArray();
		    JSONArray array7 = new JSONArray();
		    		    		    		    
		    while(rs.next())
		    {
		    	array1.add(rs.getString(1));
		    	array2.add(rs.getString(2));
		    	array3.add(rs.getString(3));
		    	array4.add(rs.getString(4));
		    	array5.add(rs.getString(5)); 
		    	array6.add(rs.getString(6)); 
		    	array7.add(rs.getString(7));
		    	 	
		    	
		    }
		    
		    jsonObject.put("Stateto", array1);
		    jsonObject.put("Statefrom", array2);
		    jsonObject.put("Travelid", array3);
		    jsonObject.put("Busid", array4);
		    jsonObject.put("Departure", array5);
		    jsonObject.put("Arrival", array6);
		    jsonObject.put("fare", array7);
		    
		    PrintWriter out=response.getWriter();
		    out.print(jsonObject.toString());
		    
		    
		    
       con.close();
			
		}catch(Exception e)
		{
			System.out.println(e);
		}
		
		
	}

}