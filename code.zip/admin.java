import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/kjsfkdfi")
public class admin extends HttpServlet {
       	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String email=request.getParameter("Email");
		String pass=request.getParameter("Password");
		
		
		
		
		try {
		
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		  
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","juhikarn");  
		  
		PreparedStatement stmt=con.prepareStatement("select adminpassword from aadmin where adminEmail =?");  
		stmt.setString(1,email);
		String dbpass=null;
		 
		ResultSet rs=stmt.executeQuery();
		if(rs.next())
		{
			dbpass=rs.getString(1);
		}
	
		
		if(pass.equals(dbpass)) {
			out.println("login success fully");
                        RequestDispatcher rd=request.getRequestDispatcher("admin1.html");
				rd.include(request, response);
		}
		else
		{
			out.println("please Enter Your correct Email and Password");
		}
		
		
		
		  
		con.close();  
		  
		}catch(Exception e){ System.out.println(e);}  
		  
		  
		 
		
		
	}

}